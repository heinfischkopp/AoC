import MyTools

with MyTools.Timer('day1'):
    with open('2022\\day1.txt', 'r') as f:
        
        elvkal = []
        n = 0 
        for line in [entry.strip() for entry in f.readlines()]:
            if len(line)==0:
                elvkal.append(n)
                n=0
            else:
                n += int(line)
    elvkal.append(n) #Nur zur Sicherheit Danke Nils
    elvkal.sort(reverse=True)

print('Lösung A: ' + str(elvkal[0]))
print('Lösung B: ' + str(elvkal[0]+elvkal[1]+elvkal[2]))