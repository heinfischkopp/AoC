
import MyTools
import re
puzzle = MyTools.AoC(21,1)

score=[0,0]
position=[] 
for line in puzzle.readLines():
    print(line)
    puzzle.toc(line)
    position.append(int(line[-1]))

d=2
runde=0

while score[0]< 1000 and score[1]< 1000 and runde < 10000:
    #puzzle.toc("Start Runde %i Pos1 %i Pos2 %i Score1 %i Score2 %i " % (runde,position[0],position[1],score[0],score[1]))
    #p1
    for player in [0,1]:
        if score[0]< 1000:#player2 nur wenn p1 nicht gewonnen hat 
            s=3*d
            runde+=1 
            position[player] = (position[player] + s -1)%10 +1
            score[player] += position[player]
            #puzzle.toc("Player %i Rolles %i moves to %i for a Score %i " % (player,s,position[player],score[player]))
            d=d+3#fixme >100
print(runde)       

puzzle.solution(runde*3*min([score[0],score[1]]))

puzzle.solution("B")